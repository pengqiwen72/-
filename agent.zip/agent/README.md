# K12 Agent — LangGraph 多智能体销售辅助系统

基于 **LangGraph** 构建的多智能体工作流系统,面向企业客服/销售场景,覆盖 **客户画像、客户标签、聊天建议、回复生成、日程安排、闲聊问答(RAG)** 六大能力,支持 **HITL(人工确认)** 与 **SSE 实时推送**。

系统由四个服务组成:

| 服务 | 目录 | 说明 |
|---|---|---|
| **k12_agent** | `k12_agent/` | LangGraph 智能体(主图 + 6 子图),核心服务 |
| **k12_sidebar** | `k12_sidebar/` | 客服侧边栏 Web(FastAPI + 原生前端,SSE 交互) |
| **k12_admin** | `k12_admin/` | 只读管理后台(Flask + Bootstrap) |
| **k12_client** | `k12_client/` | 数据初始化与写入工具 |

## 架构

```
┌────────────┐   SSE/HTTP   ┌──────────────┐  langgraph-sdk  ┌─────────────────┐
│  侧边栏前端  │ ──────────→ │  k12_sidebar  │ ──────────────→ │  k12_agent 服务   │
│ (Web)       │ ←────────── │ (FastAPI 代理) │ ←────────────── │  (LangGraph 图)  │
└────────────┘  流式响应     └──────────────┘   HTTP 长连接     └─────────────────┘
```

### LangGraph 主图流程

```
用户输入(task_input: 指令名 或 闲聊内容)
    ↓
主图 StateGraph(意图检测 → 数据加载 → 子图路由)
    ├─ 加载多源数据:员工 / 客户 / 聊天记录 / 订单 / 标签 / 画像
    ├─ 意图路由分发到子图:
    │    ├─ 客户画像子图   (LLM 抽取画像 → interrupt 人工确认 → 落库)
    │    ├─ 客户标签子图   (LLM 生成标签 → interrupt 人工确认 → 落库)
    │    ├─ 聊天建议子图   (生成回复话术)
    │    ├─ 客服聊天建议子图(微信客服话术)
    │    ├─ 日程安排子图   (跟进计划/提醒)
    │    └─ 闲聊子图       (RAG 知识库问答,未明确意图兜底)
    └─ 汇总各子图结果,合并会话状态
```

### 关键设计

- **状态管理**:State 字段通过自定义 `reducer` 增量合并,多子图结果互不覆盖
- **HITL 人工确认**:关键建议经 `interrupt` 挂起,支持确认 / 丢弃 / 重新生成
- **线程隔离**:thread_id = UUID5(user_id + external_id),同用户多轮会话持续
- **RAG 问答**:闲聊子图基于 ChromaDB + Embedding 检索私有知识库,带置信度阈值兜底
- **可观测性**:Langfuse / LangSmith 链路追踪,Token 统计

## 快速开始

> 前置:Python ≥ 3.12、uv、一个 OpenAI 兼容的 LLM 服务(如阿里云百炼 DashScope)

```bash
# 0. 每个服务复制环境变量模板并填写
cd k12_agent && cp .env.example .env   # 填写 API_KEY、模型名等
cd k12_sidebar && cp .env.example .env
cd k12_admin && cp .env.example .env
cd k12_client && cp .env.example .env

# 1. 启动 Agent 服务(在 k12_agent 目录)
uv sync
PYTHONPATH=. .venv/Scripts/python.exe -m langgraph dev   # 或 docker compose up

# 2. (可选)构建 RAG 知识库(在 k12_agent 目录)
#    把知识文档放进 data/knowledge_docs/,然后:
PYTHONPATH=src .venv/Scripts/python.exe -m rag.build_knowledge_base --rebuild

# 3. 启动侧边栏(在 k12_sidebar 目录)
uv sync
PYTHONPATH=. .venv/Scripts/python.exe main.py            # 默认 8001

# 4. 启动管理后台(在 k12_admin 目录)
uv sync
PYTHONPATH=. .venv/Scripts/python.exe k12_admin_app.py   # 默认 5000

# 5. (可选)初始化演示数据(在 k12_client 目录)
uv sync
PYTHONPATH=. .venv/Scripts/python.exe store_client/k12_demo_init.py
```

浏览器访问侧边栏,使用 `.env` 中配置的 Web 账号登录。

## 目录结构

```
k12_profile/
├── k12_agent/                 # LangGraph 智能体服务
│   ├── langgraph.json         # LangGraph 服务配置(graph/auth 定义)
│   ├── src/
│   │   ├── auth/              # langgraph-sdk Auth 鉴权
│   │   ├── graphs/k12_graph/  # 主图 StateGraph + 6 子图
│   │   ├── llm/               # LLM 调用层(各任务 Prompt 封装)
│   │   ├── models/            # Pydantic 数据模型(含 BaseModel 基类)
│   │   ├── rag/               # RAG 知识库(构建 + 检索)
│   │   ├── store/             # LangGraph Store 封装
│   │   ├── tools/             # 业务工具(store_tool / wechat_tool)
│   │   ├── utils/             # 日志 / 调试 / 时间工具
│   │   └── webapp/            # FastAPI 入口(health / get_token)
│   └── data/                  # 知识库文档与向量库(不入库)
├── k12_sidebar/               # 客服侧边栏(FastAPI + 原生 JS)
├── k12_admin/                 # 只读管理后台(Flask + Bootstrap)
├── k12_client/                # 数据初始化/写入工具
└── .gitignore
```

## 技术栈

LangGraph · langgraph-sdk · LangChain · Qwen(通义千问) · FastAPI · Flask · SSE · JWT · Pydantic · ChromaDB · Langfuse

## License

MIT
