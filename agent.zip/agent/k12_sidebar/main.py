def main():
    print("Hello from k12-sidebar!")


if __name__ == "__main__":
    main()
