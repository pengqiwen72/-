"""RAG 检索机制验证脚本(不依赖真实 API key)
- 用临时内存 ChromaDB + 假 embedding 验证: 构建->检索->格式化->子图检索节点
- 运行: cd k12_agent && PYTHONPATH=src .venv/Scripts/python.exe test_rag_mechanics.py
"""
import hashlib
from pathlib import Path

import numpy as np
from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings


class FakeEmbeddings(Embeddings):
    """确定性伪 embedding: 字符哈希 -> 归一化向量"""
    def __init__(self, dim=64):
        self.dim = dim

    def _vec(self, text):
        v = np.zeros(self.dim)
        for ch in text:
            v[ord(ch) % self.dim] += 1
        n = np.linalg.norm(v)
        return (v / n).tolist() if n else v.tolist()

    def embed_documents(self, texts):
        return [self._vec(t) for t in texts]

    def embed_query(self, text):
        return self._vec(text)


def main():
    # 1. 用示例文档构建内存向量库
    docs_dir = Path("data/knowledge_docs")
    documents = []
    for f in sorted(docs_dir.glob("*.md")):
        documents.append(Document(page_content=f.read_text(encoding="utf-8"), metadata={"source": f.name}))

    store = Chroma.from_documents(
        documents=documents,
        embedding=FakeEmbeddings(),
        collection_name="test_k12",
        collection_metadata={"hnsw:space": "cosine"},
    )
    print(f"[1] 内存向量库构建完成: {store._collection.count()} 个文档")

    # 2. 把真实 retrieve() 的底层 store 替换为这个假 store
    import rag.knowledge_retriever as kr
    kr.get_vector_store = lambda: store
    kr.KNOWLEDGE_DB_DIR = Path(".")  # 绕过 exists() 检查

    hits = kr.retrieve("小班课多少钱一节?", top_k=3, score_threshold=0.9)
    print(f"[2] 检索'小班课多少钱一节?' -> 命中 {len(hits)} 条 (score阈值放宽到0.9以适配假向量)")
    assert hits, "检索应至少命中1条"
    for h in hits:
        print(f"    - score={h['score']} source={h['source']} 内容前40字: {h['content'][:40]!r}")

    context = kr.format_context(hits)
    assert "片段1" in context and "来源" in context
    print(f"[3] format_context 格式化成功, 长度 {len(context)} 字符")

    # 3. 验证子图检索节点(不触发 LLM)
    from graphs.k12_graph.k12_sub_graph_talk import sub_talk_graph as mod
    mod.retrieve = lambda question: hits  # 注入命中结果, 跳过真实检索

    update = mod.rag_retrieve_node({"task_input": "小班课多少钱?"}, {})
    assert update["rag_context"], "检索节点应写入 rag_context"
    msg = update["node_result"][0].execute_result_msg
    print(f"[4] rag_retrieve_node 执行成功: node_result={msg}")
    assert "检索到" in msg

    # 4. 未命中分支
    mod.retrieve = lambda question: []
    update2 = mod.rag_retrieve_node({"task_input": "今天天气怎么样"}, {})
    assert update2["rag_context"] == ""
    print(f"[5] 未命中分支正常: node_result={update2['node_result'][0].execute_result_msg}")

    # 5. 主图整体编译需要 LangGraph 运行时上下文(store_client 模块级实例化),
    #    普通脚本无法导入 —— 这是原有设计的限制, 与本次改动无关。
    #    子图独立编译已在上述步骤验证通过。
    print("[6] 主图导入需在 langgraph server 运行时内执行(原有限制, 跳过)")

    print("\n=== 全部机制验证通过 ===")


if __name__ == "__main__":
    main()
