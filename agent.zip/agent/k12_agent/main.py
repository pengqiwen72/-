def main():
    print("Hello from k12-agent!")


if __name__ == "__main__":
    main()
