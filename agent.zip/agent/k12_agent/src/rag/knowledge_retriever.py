"""
知识库检索器
- 供 LangGraph 子图节点调用: 问题向量化 -> ChromaDB 相似度检索 -> top-k 片段
- 用法: from rag.knowledge_retriever import retrieve
"""
import os
from pathlib import Path

from dotenv import load_dotenv
from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings

BASE_DIR = Path(__file__).resolve().parents[2]

load_dotenv(BASE_DIR / ".env")

KNOWLEDGE_DB_DIR = Path(os.getenv("KNOWLEDGE_DB_DIR", str(BASE_DIR / "data" / "knowledge_db")))
COLLECTION_NAME = os.getenv("KNOWLEDGE_COLLECTION", "k12_knowledge")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "text-embedding-v3")
EMBEDDING_BASE_URL = os.getenv("EMBEDDING_BASE_URL", os.getenv("BASE_URL"))
EMBEDDING_API_KEY = os.getenv("EMBEDDING_API_KEY", os.getenv("API_KEY"))

# 检索参数(可用环境变量覆盖)
DEFAULT_TOP_K = int(os.getenv("RAG_TOP_K", "3"))
# Chroma 默认使用 L2 距离(cosine 空间下 = 1 - 余弦相似度), 越小越相关
# 0.45 对应余弦相似度约 0.55, 低于该值视为"没命中"
DEFAULT_THRESHOLD = float(os.getenv("RAG_THRESHOLD", "0.45"))


def get_embedding_model() -> OpenAIEmbeddings:
    if not EMBEDDING_BASE_URL or not EMBEDDING_API_KEY:
        raise RuntimeError("缺少 EMBEDDING_BASE_URL / EMBEDDING_API_KEY(或 BASE_URL / API_KEY)环境变量")
    return OpenAIEmbeddings(
        model=EMBEDDING_MODEL,
        base_url=EMBEDDING_BASE_URL,
        api_key=EMBEDDING_API_KEY,
        chunk_size=16,
    )


def get_vector_store() -> Chroma:
    return Chroma(
        collection_name=COLLECTION_NAME,
        embedding_function=get_embedding_model(),
        persist_directory=str(KNOWLEDGE_DB_DIR),
        collection_metadata={"hnsw:space": "cosine"},
    )


def retrieve(
    question: str,
    top_k: int = DEFAULT_TOP_K,
    score_threshold: float = DEFAULT_THRESHOLD,
) -> list:
    """
    检索与问题最相关的知识片段

    Returns:
        list[dict]: [{"content": str, "source": str, "score": float}] 按相关度排序,
                    若向量库不存在或全部低于阈值, 返回空列表
    """
    if not KNOWLEDGE_DB_DIR.exists():
        return []

    try:
        vector_store = get_vector_store()
    except Exception as e:
        print(f"[rag] 打开向量库失败: {e}")
        return []

    try:
        results = vector_store.similarity_search_with_score(question, k=top_k)
    except Exception as e:
        print(f"[rag] 检索失败: {e}")
        return []

    hits = []
    for doc, distance in results:
        # distance 越小越相关; 超过阈值说明不够相关, 直接截断(结果已按距离升序)
        if distance > score_threshold:
            break
        hits.append({
            "content": doc.page_content,
            "source": doc.metadata.get("source", "未知来源"),
            "score": round(distance, 4),
        })
    return hits


def format_context(hits: list) -> str:
    """把检索结果格式化为 prompt 中的上下文文本"""
    if not hits:
        return ""
    parts = []
    for i, hit in enumerate(hits, start=1):
        parts.append(f"[片段{i}] (来源: {hit['source']})\n{hit['content'].strip()}")
    return "\n\n".join(parts)


if __name__ == "__main__":
    # 快速自测: PYTHONPATH=src .venv/Scripts/python.exe -m rag.knowledge_retriever "小班课多少钱"
    import sys

    question = sys.argv[1] if len(sys.argv) > 1 else "小班课多少钱"
    print(f"问题: {question}")
    hits = retrieve(question)
    if not hits:
        print(">>> 未命中知识库")
    else:
        for hit in hits:
            print(f"\n--- score={hit['score']} source={hit['source']} ---")
            print(hit["content"][:120])
