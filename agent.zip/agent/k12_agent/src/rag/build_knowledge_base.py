"""
知识库构建脚本
- 读取 data/knowledge_docs/ 下的 markdown/txt 文档
- 切块 -> 向量化 -> 持久化到 data/knowledge_db/ (ChromaDB)
- 用法: PYTHONPATH=src .venv/Scripts/python.exe -m rag.build_knowledge_base [--rebuild]
"""
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from langchain_chroma import Chroma
from langchain_openai import OpenAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter

# 项目根目录 = src/rag/../.. = k12_agent
BASE_DIR = Path(__file__).resolve().parents[2]

load_dotenv(BASE_DIR / ".env")

KNOWLEDGE_DOCS_DIR = Path(os.getenv("KNOWLEDGE_DOCS_DIR", str(BASE_DIR / "data" / "knowledge_docs")))
KNOWLEDGE_DB_DIR = Path(os.getenv("KNOWLEDGE_DB_DIR", str(BASE_DIR / "data" / "knowledge_db")))
COLLECTION_NAME = os.getenv("KNOWLEDGE_COLLECTION", "k12_knowledge")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "text-embedding-v3")
EMBEDDING_BASE_URL = os.getenv("EMBEDDING_BASE_URL", os.getenv("BASE_URL"))
EMBEDDING_API_KEY = os.getenv("EMBEDDING_API_KEY", os.getenv("API_KEY"))

CHUNK_SIZE = int(os.getenv("KB_CHUNK_SIZE", "400"))
CHUNK_OVERLAP = int(os.getenv("KB_CHUNK_OVERLAP", "50"))


def get_embedding_model() -> OpenAIEmbeddings:
    """创建 embedding 模型实例(复用阿里云 dashscope 的 key)"""
    if not EMBEDDING_BASE_URL or not EMBEDDING_API_KEY:
        raise RuntimeError("缺少 EMBEDDING_BASE_URL / EMBEDDING_API_KEY(或 BASE_URL / API_KEY)环境变量")
    return OpenAIEmbeddings(
        model=EMBEDDING_MODEL,
        base_url=EMBEDDING_BASE_URL,
        api_key=EMBEDDING_API_KEY,
        chunk_size=16,  # 避免大批量请求被限流
    )


def load_documents(docs_dir: Path) -> list:
    """读取 docs_dir 下所有 .md / .txt 文件为 Document"""
    from langchain_core.documents import Document

    documents = []
    for file_path in sorted(docs_dir.glob("*.md")) + sorted(docs_dir.glob("*.txt")):
        content = file_path.read_text(encoding="utf-8")
        if not content.strip():
            continue
        documents.append(Document(
            page_content=content,
            metadata={"source": file_path.name},
        ))
        print(f"  [加载] {file_path.name} ({len(content)} 字符)")
    return documents


def split_documents(documents: list) -> list:
    """按块大小切分文档"""
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        separators=["\n## ", "\n### ", "\n- ", "\n", "。", "！", "？"],
    )
    chunks = splitter.split_documents(documents)
    print(f"  [切块] 共切出 {len(chunks)} 个片段 (chunk_size={CHUNK_SIZE}, overlap={CHUNK_OVERLAP})")
    return chunks


def build(rebuild: bool = False):
    print(f"知识库文档目录: {KNOWLEDGE_DOCS_DIR}")
    print(f"向量库持久化目录: {KNOWLEDGE_DB_DIR}")
    print(f"Embedding 模型: {EMBEDDING_MODEL}")

    if not KNOWLEDGE_DOCS_DIR.exists():
        raise FileNotFoundError(f"知识库文档目录不存在: {KNOWLEDGE_DOCS_DIR}")

    documents = load_documents(KNOWLEDGE_DOCS_DIR)
    if not documents:
        raise RuntimeError(f"目录 {KNOWLEDGE_DOCS_DIR} 下没有 .md/.txt 文档")

    chunks = split_documents(documents)

    KNOWLEDGE_DB_DIR.mkdir(parents=True, exist_ok=True)

    embeddings = get_embedding_model()
    if rebuild:
        print("  [重建] 删除已有 collection ...")
        Chroma(
            collection_name=COLLECTION_NAME,
            embedding_function=embeddings,
            persist_directory=str(KNOWLEDGE_DB_DIR),
        ).delete_collection()

    print("  [向量化] 写入 ChromaDB ...")
    vector_store = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        collection_name=COLLECTION_NAME,
        persist_directory=str(KNOWLEDGE_DB_DIR),
        collection_metadata={"hnsw:space": "cosine"},  # 使用余弦距离, 越小越相关
    )
    print(f"  [完成] 向量库已构建: {vector_store._collection.count()} 个片段")


if __name__ == "__main__":
    rebuild = "--rebuild" in sys.argv
    build(rebuild=rebuild)
