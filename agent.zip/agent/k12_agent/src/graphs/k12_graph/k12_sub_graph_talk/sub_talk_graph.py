import operator
from typing import TypedDict, Annotated, List
from enum import Enum
from langgraph.graph import StateGraph, START, END
from langchain_core.runnables import RunnableConfig
from utils.agent_logger import get_logger
from llm.llm_rag_talk import llm_rag_talk
from rag.knowledge_retriever import retrieve, format_context
from graphs.k12_graph.k12_state import K12StateField
from graphs.k12_graph.k12_state import K12Config
from models.k12_models import TaskResult, NodeResult, JustTalkOutput, ChatHistory, CustomerInfo, CustomerProfile

logger = get_logger("sub_talk_graph")

class SubTalkStateField(str, Enum):
    TASK_INPUT       = K12StateField.TASK_INPUT.value
    TASK_RESULT      = K12StateField.TASK_RESULT.value
    NODE_RESULT      = K12StateField.NODE_RESULT.value
    CHAT_HISTORY     = K12StateField.CHAT_HISTORY.value
    CUSTOMER_INFO    = K12StateField.CUSTOMER_INFO.value
    CUSTOMER_PROFILE = K12StateField.CUSTOMER_PROFILE.value
    RAG_CONTEXT      = "rag_context"

class SubTalkInputState(TypedDict):
    """
    子图输入: 除 task_input 外, 还透传主图已加载的客户上下文
    (若不声明, 这些字段会在子图入口被 input_schema 过滤掉)
    """
    task_input: str
    chat_history: ChatHistory
    customer_info: CustomerInfo
    customer_profile: CustomerProfile

class SubTalkOutputState(TypedDict):
    task_result: TaskResult
    node_result: Annotated[List[NodeResult], operator.add]

# 使用多重继承，自动合并所有字段
class SubTalkState(SubTalkInputState, SubTalkOutputState):
    """
    完整的子图状态，包含输入和输出字段
    - 从主图流入: chat_history / customer_info / customer_profile
    - 子图内部产生: rag_context (知识库检索结果)
    """
    chat_history: ChatHistory
    customer_info: CustomerInfo
    customer_profile: CustomerProfile
    rag_context: str


class NodeName(str, Enum):
    WELCOME_MESSAGE = "talk_welcome_node"
    RAG_RETRIEVE    = "talk_rag_retrieve_node"
    JUST_TALK       = "talk_reply_node"

def welcome_message_node(state: SubTalkState, config: RunnableConfig):
    """欢迎消息节点"""

    logger.info("=== 欢迎消息 ===")

    return {
        SubTalkStateField.NODE_RESULT: [NodeResult(
            execute_node_name=NodeName.JUST_TALK.value,
            execute_result_code=0,
            execute_result_msg="正在为您生成回复，请稍等。",
            execute_exceptions=[]
        )]
    }

def rag_retrieve_node(state: SubTalkState, config: RunnableConfig):
    """知识库检索节点 - 从 ChromaDB 检索与问题相关的知识片段"""

    logger.info("=== 知识库检索 ===")

    question = state.get(SubTalkStateField.TASK_INPUT, "")
    hits = retrieve(question)
    rag_context = format_context(hits)

    if rag_context:
        logger.info(f"知识库命中 {len(hits)} 个片段")
        return {
            SubTalkStateField.RAG_CONTEXT: rag_context,
            SubTalkStateField.NODE_RESULT: [NodeResult(
                execute_node_name=NodeName.RAG_RETRIEVE.value,
                execute_result_code=0,
                execute_result_msg=f"已从知识库检索到 {len(hits)} 条相关资料",
                execute_exceptions=[]
            )]
        }

    logger.info("知识库未命中，将使用客户上下文/自由问答")
    return {
        SubTalkStateField.RAG_CONTEXT: "",
        SubTalkStateField.NODE_RESULT: [NodeResult(
            execute_node_name=NodeName.RAG_RETRIEVE.value,
            execute_result_code=0,
            execute_result_msg="知识库未检索到相关资料，将基于客户背景回答",
            execute_exceptions=[]
        )]
    }

def just_talk_node(state: SubTalkState, config: RunnableConfig):
    """咨询回复节点 - RAG 问答(知识库 + 客户上下文 + 聊天记录)"""

    logger.info("=== 咨询回复(RAG) ===")

    try:
        generated_just_talk_output: JustTalkOutput = llm_rag_talk(
            question=state.get(SubTalkStateField.TASK_INPUT, ""),
            rag_context=state.get(SubTalkStateField.RAG_CONTEXT, ""),
            chat_history=state.get(SubTalkStateField.CHAT_HISTORY),
            customer_profile=state.get(SubTalkStateField.CUSTOMER_PROFILE),
        )
        logger.info(f"generated_just_talk_output: {generated_just_talk_output}")

        if not generated_just_talk_output.just_talk_output:
            return {
                SubTalkStateField.TASK_RESULT: TaskResult(
                    task_result="我好像没有理解你的意思",
                    task_result_explain="生成回复失败",
                    task_result_code=1
                ),
                SubTalkStateField.NODE_RESULT: [NodeResult(
                    execute_node_name=NodeName.JUST_TALK.value,
                    execute_result_code=1,
                    execute_result_msg="生成回复失败",
                    execute_exceptions=["生成回复失败"]
                )]
            }

        return {
            SubTalkStateField.TASK_RESULT: TaskResult(
                task_result=generated_just_talk_output.just_talk_output,
                task_result_explain="生成回复成功",
                task_result_code=0
            ),
            SubTalkStateField.NODE_RESULT: [NodeResult(
                execute_node_name=NodeName.JUST_TALK.value,
                execute_result_code=0,
                execute_result_msg="生成回复成功",
                execute_exceptions=[]
            )]
        }
    except Exception as e:
        logger.error(f"生成回复失败: {e}")
        return {
            SubTalkStateField.TASK_RESULT: TaskResult(
                task_result="抱歉，我好像有故障，无法回答你的问题",
                task_result_explain="解析失败",
                task_result_code=1
            ),
            SubTalkStateField.NODE_RESULT: [NodeResult(
                execute_node_name=NodeName.JUST_TALK.value,
                execute_result_code=1,
                execute_result_msg="解析失败",
                execute_exceptions=[f"解析结果失败: {e}"]
            )]
        }

builder = StateGraph(state_schema=SubTalkState, input_schema=SubTalkInputState, output_schema=SubTalkOutputState, config_schema=K12Config)

builder.add_node(NodeName.WELCOME_MESSAGE.value, welcome_message_node)
builder.add_node(NodeName.RAG_RETRIEVE.value, rag_retrieve_node)
builder.add_node(NodeName.JUST_TALK.value, just_talk_node)

builder.add_edge(START, NodeName.WELCOME_MESSAGE.value)
builder.add_edge(NodeName.WELCOME_MESSAGE.value, NodeName.RAG_RETRIEVE.value)
builder.add_edge(NodeName.RAG_RETRIEVE.value, NodeName.JUST_TALK.value)
builder.add_edge(NodeName.JUST_TALK.value, END)

sub_talk_graph = builder.compile()
