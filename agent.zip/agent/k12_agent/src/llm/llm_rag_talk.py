"""
RAG 问答 LLM 调用
- 相比 llm_just_talk: prompt 中注入 知识库检索片段 + 客户背景 + 聊天记录
- 知识库未命中时自动降级: 结合客户背景回答, 两者都没有则正常闲聊并提示咨询顾问
"""
from typing import Optional

from llm.llm_setting import chat_model as llm
from langchain_core.messages import AIMessage
from utils.agent_logger import get_logger
from models.k12_models import JustTalkOutput, ChatHistory, CustomerProfile

logger = get_logger("llm_rag_talk")


def _format_customer_profile(profile: Optional[CustomerProfile]) -> str:
    """把客户画像格式化为文本: 姓名: 值"""
    if not profile or not getattr(profile, "profile_items", None):
        return ""
    lines = [f"{item.item_name}: {item.item_value}" for item in profile.profile_items]
    return "\n".join(lines)


def _format_chat_history(history: Optional[ChatHistory]) -> str:
    """把聊天记录格式化为文本"""
    if not history or not getattr(history, "chat_msgs", None):
        return ""
    lines = [f"{msg.sender}: {msg.content}" for msg in history.chat_msgs[-10:]]
    return "\n".join(lines)


def llm_rag_talk(
    question: str,
    rag_context: str = "",
    chat_history: Optional[ChatHistory] = None,
    customer_profile: Optional[CustomerProfile] = None,
) -> JustTalkOutput:
    customer_text = _format_customer_profile(customer_profile)
    chat_text = _format_chat_history(chat_history)

    prompt = _rag_talk_instructions.format(
        knowledge_context=rag_context if rag_context else "（无）",
        customer_background=customer_text if customer_text else "（无）",
        chat_history_text=chat_text if chat_text else "（无）",
        input=question,
        schema_json=JustTalkOutput.get_schema_json(),
        example_json=JustTalkOutput.get_example_json(),
    )
    logger.debug(f"prompt: {prompt[:2000]}")

    generated_result: AIMessage = llm.invoke(prompt)
    logger.debug(f"generated_result: {generated_result}")

    if generated_result and generated_result.content:
        just_talk_json = generated_result.content
    else:
        just_talk_json = "{}"

    try:
        just_talk = JustTalkOutput.model_validate_json(just_talk_json)
    except Exception as e:
        logger.error(f"解析JustTalkOutput失败: {e}")
        just_talk = JustTalkOutput()

    logger.info(f"just_talk: {just_talk.model_dump_json()}")
    return just_talk


_rag_talk_instructions = """\
你是一个教培机构(擎天学智)的智能助手，帮助公司员工(课程顾问/客服)回答关于课程产品、价格优惠、师资、报名政策等问题，也可以陪用户闲聊。

请按以下优先级组织回答：
1. 【知识库内容】有相关信息时：严格依据知识库回答，不要编造知识库中没有的细节(如价格数字、政策条款)；可以注明信息来源。
2. 【知识库内容】没有、但【客户背景】有相关信息时：结合客户背景给出个性化建议(如孩子年级对应的班型、薄弱学科对应的课程)。
3. 两者都没有相关信息时：明确说明"目前暂无相关资料，建议咨询课程顾问"，不要编造课程和价格信息；如果是闲聊寒暄类内容，正常友好回应即可。

回答要求：
- 语气亲切专业，面向教培机构员工，最终回复会被员工参考后发给家长。
- 不要编造知识库中没有的具体数字、政策、承诺。
- 严格按照 JustTalkOutput 数据结构定义返回JSON。
【注意】请不要在JSON对象前后包含任何文本。也不要包含"```json"或者"```"这样的文本。
【注意】请不要在json对象中包含任何未定义的字段。

这里是JustTalkOutput的数据结构定义：
-------------------
{schema_json}
-------------------

json对象示例：
-------------------
{example_json}
-------------------

【知识库内容】(检索到的相关资料):
-------------------
{knowledge_context}
-------------------

【客户背景】(客户画像):
-------------------
{customer_background}
-------------------

【近期聊天记录】:
-------------------
{chat_history_text}
-------------------

员工输入的问题：
-------------------
{input}
-------------------
"""
