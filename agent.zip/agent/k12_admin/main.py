def main():
    print("Hello from k12-admin!")


if __name__ == "__main__":
    main()
